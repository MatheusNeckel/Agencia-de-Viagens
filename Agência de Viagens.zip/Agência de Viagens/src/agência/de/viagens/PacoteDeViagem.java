package agência.de.viagens;

public class PacoteDeViagem {

    private String destino;
    private int quantidadeDeDias;
    private Transporte t;
    private Hospedagem h;

    public PacoteDeViagem() {
    }

    public PacoteDeViagem(String destino, int quantidadeDeDias, Transporte t, Hospedagem h) {
        this.destino = destino;
        this.quantidadeDeDias = quantidadeDeDias;
        this.t = t;
        this.h = h;
    }

    public double calcularValorTotalHospedagem() {
        return (quantidadeDeDias * h.getValorDiaria());
    }

    public double calcularValorDeLucro(double valorInformado, double porcentagem) {
        return valorInformado + (valorInformado * (porcentagem / 100));
    }

    public double calcularValorTotalDoPacote(double valorDeLucro) {
        double valorTotalDoPacote = t.getValor() + calcularValorTotalHospedagem() + valorDeLucro;
        return valorTotalDoPacote;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public int getQuantidadeDeDias() {
        return quantidadeDeDias;
    }

    public void setQuantidadeDeDias(int quantidadeDeDias) {
        this.quantidadeDeDias = quantidadeDeDias;
    }

    public Transporte getT() {
        return t;
    }

    public void setT(Transporte t) {
        this.t = t;
    }

    public Hospedagem getH() {
        return h;
    }

    public void setH(Hospedagem h) {
        this.h = h;
    }
}
