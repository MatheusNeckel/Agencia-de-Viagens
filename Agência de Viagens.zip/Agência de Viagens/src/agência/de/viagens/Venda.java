package agência.de.viagens;

public class Venda {

    private String nomeDoCliente, formaDePagamento;
    private PacoteDeViagem p;

    public Venda() {
    }

    public Venda(String nomeDoCliente, String formaDePagamento, PacoteDeViagem p) {
        this.nomeDoCliente = nomeDoCliente;
        this.formaDePagamento = formaDePagamento;
        this.p = p;
    }

    public double converterDolarReal(double valor, double cotacao) {
        return valor * cotacao;
    }

    public void mostrarTotalPacote(double cotacao, double valorDeLucro) {
        System.out.println("Total do pacote (em dólares): " + p.calcularValorTotalDoPacote(valorDeLucro));
        System.out.println("Total do pacote em reais: " + converterDolarReal(p.calcularValorTotalDoPacote(valorDeLucro), cotacao));
    }

    public String getNomeDoCliente() {
        return nomeDoCliente;
    }

    public void setNomeDoCliente(String nomeDoCliente) {
        this.nomeDoCliente = nomeDoCliente;
    }

    public String getFormaDePagamento() {
        return formaDePagamento;
    }

    public void setFormaDePagamento(String formaDePagamento) {
        this.formaDePagamento = formaDePagamento;
    }

    public PacoteDeViagem getP() {
        return p;
    }

    public void setP(PacoteDeViagem p) {
        this.p = p;
    }
}
