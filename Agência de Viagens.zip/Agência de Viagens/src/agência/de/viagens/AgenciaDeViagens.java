package agência.de.viagens;

import java.util.Scanner;

public class AgenciaDeViagens {

    public static void main(String[] args) {
        Scanner entrada = new Scanner(System.in);

        System.out.println("\n----Criar o Pacote de Viagem----");

        System.out.println("\n--Transporte--");
        System.out.print("Escolha o transporte da viagem: ");
        String tipo = entrada.next();
        System.out.println("Você escolheu: " + tipo);
        System.out.print("Valor da passagem: R$ ");
        double valor = entrada.nextDouble();

        Transporte t = new Transporte(tipo, valor);
        System.out.println("Transporte criado com sucesso!");

        System.out.println("\n--Hospedagem--");
        System.out.print("Informe a descrição da hospedagem: ");
        String descricao = entrada.next();
        System.out.print("Valor diária: R$ ");
        double valorDiaria = entrada.nextDouble();

        Hospedagem h = new Hospedagem(descricao, valorDiaria);
        System.out.println("Hospedagem criado com sucesso!");

        System.out.print("\nEscolha o destino da sua viagem: ");
        String destino = entrada.next();
        System.out.print("Digite quantos dias será a viagem: ");
        int quantidadeDeDias = entrada.nextInt();

        PacoteDeViagem p = new PacoteDeViagem(destino, quantidadeDeDias, t, h);

        System.out.println("\nPacote de viagem criado com sucesso!");

        System.out.print("\nDigite um valor adicional: ");
        double valorInformado = entrada.nextDouble();
        System.out.print("Digite uma porcentagem: ");
        double porcentagem = entrada.nextDouble();

        double valoresAdicionais = p.calcularValorDeLucro(valorInformado, porcentagem);

        System.out.println("----Pacote de Viagem----");
        System.out.println("Destino: " + p.getDestino());
        System.out.println(p.getQuantidadeDeDias() + " noites de hospedagem");
        System.out.println("Transporte: " + p.getT().getTipo());
        System.out.println("Valor do transporte: " + p.getT().getValor());
        System.out.println("Hospedagem: " + p.getH().getDescricao());
        System.out.println("Valor da hospedagem: " + p.calcularValorTotalHospedagem());
        System.out.println("Valores adicionais: " + valoresAdicionais);
        System.out.println("Valor total do pacote: " + p.calcularValorTotalDoPacote(valoresAdicionais));

        System.out.print("\nDigite o nome do cliente: ");
        String nomeDoCliente = entrada.next();
        System.out.print("\nEscolha a forma de pagamento: ");
        String formaDePagamento = entrada.next();

        Venda v = new Venda(nomeDoCliente, formaDePagamento, p);

        System.out.println("\nVenda efetuada com sucesso!");
        System.out.print("\nDigite a cotação atual do dólar: ");
        double cotacao = entrada.nextDouble();
        v.mostrarTotalPacote(cotacao, valoresAdicionais);
    }
}
